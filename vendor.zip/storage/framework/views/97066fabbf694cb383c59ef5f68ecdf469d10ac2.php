<?php $__env->startSection('title'); ?>
    Manage User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    Manage User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <section>
        <div class="row">
            <div class="col-md-12">
                <div class="card shadow">
                    <div class="card-body">
                        <table class="table table-bordered ">
                            <tr class="">
                                <th>Name</th>
                                <th><?php echo e($front_user->name); ?></th>
                            </tr>
                            <tr class="">
                                <th>Email</th>
                                <th><?php echo e($front_user->email); ?></th>
                            </tr>
                            <tr class="">
                                <th>Whatsapp no</th>
                                <th><?php echo e($front_user->whatsapp_no); ?></th>
                            </tr>
                            <tr class="">
                                <th>Address</th>
                                <th><?php echo e($front_user->whatsapp_no); ?></th>
                            </tr>
                            <tr class="">
                                <th>Tiktok username</th>
                                <th><?php echo e($front_user->tiktok_username); ?></th>
                            </tr>
                            <tr class="">
                                <th>Tiktok password</th>
                                <th><?php echo e($front_user->tiktok_password); ?></th>
                            </tr>
                            <tr class="">
                                <th>Tiktok county</th>
                                <th><?php echo e($front_user->tiktok_county); ?></th>
                            </tr>
                            <tr class="">
                                <th>Tiktok target interest</th>
                                <th><?php echo e($front_user->tiktok_target_interest); ?></th>
                            </tr>
                            <tr class="">
                                <th>Tiktok follower no</th>
                                <th><?php echo e($front_user->tiktok_follower_no); ?></th>
                            </tr>
                            <tr class="">
                                <th>Next billing date</th>
                                <th><?php echo e($AgreementDetails->agreement_details->next_billing_date); ?></th>
                            </tr>

                            <tr class="">
                                <th>Last payment date</th>
                                <th><?php echo e($AgreementDetails->agreement_details->last_payment_date); ?></th>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back-end.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\paypal-project\resources\views/back-end/single-view/single-view.blade.php ENDPATH**/ ?>