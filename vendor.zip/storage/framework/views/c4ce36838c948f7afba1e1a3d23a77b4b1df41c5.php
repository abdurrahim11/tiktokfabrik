<!DOCTYPE html>
<html lang="en-US" class="no-js">

<!-- Mirrored from tiktokfabrik.de/checkout-woo/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 10 Nov 2019 20:05:57 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<!-- /Added by HTTrack -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <title>Subscribe</title>
    <link rel='stylesheet' id='qlwapp-css' href='<?php echo e(asset('/')); ?>oldfile/wp-content/plugins/wp-whatsapp-chat/assets/css/qlwapp.min2827.css?ver=4.4.8' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-icons-css' href='<?php echo e(asset('/')); ?>oldfile/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.minb2f9.css?ver=4.3.0' type='text/css' media='all' />
    <link rel='stylesheet' id='font-awesome-css' href='<?php echo e(asset('/')); ?>oldfile/wp-content/plugins/elementor/assets/lib/font-awesome/css/font-awesome.min1849.css?ver=4.7.0' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-animations-css' href='<?php echo e(asset('/')); ?>oldfile/wp-content/plugins/elementor/assets/lib/animations/animations.min737b.css?ver=2.5.15' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-frontend-css' href='<?php echo e(asset('/')); ?>oldfile/wp-content/plugins/elementor/assets/css/frontend.min737b.css?ver=2.5.15' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-pro-css' href='<?php echo e(asset('/')); ?>oldfile/wp-content/plugins/elementor-pro/assets/css/frontend.mined42.css?ver=2.5.8' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-global-css' href='<?php echo e(asset('/')); ?>oldfile/wp-content/uploads/elementor/css/global42af.css?ver=1572446417' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-post-84-css' href='<?php echo e(asset('/')); ?>oldfile/wp-content/uploads/elementor/css/post-84b453.css?ver=1572447251' type='text/css' media='all' />

    <!-- Custom fonts for this template-->
    <link href="<?php echo e(asset('/')); ?>asset/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo e(asset('/')); ?>asset/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('/')); ?>asset/css/style.css" rel="stylesheet">
    <style>

       label.paypal-area {
           margin: 0;
           font-size: 20px;
           font-weight: 800;
           padding: 3px 0px 15px 0px;
       }

       input.btn.btn-success.btn-block {
           background: #4167F9;
           margin: 0;
           padding: 13px 10px;
           font-size: 27px;
           font-weight: 600;
       }
       label {
           color: black;
           font-weight: 700;
       }
       section.footer {
           background: #022E47;
           padding: 50px 0px;
           text-align: center;
       }

       .footer-left {}

       .footer-left h3 {color: white;font-weight: 700;}

       .footer-left p {
           color: #ffff;
           font-size: 16px;
       }

       .footer-center ul {
           list-style: none;
       }

       .footer-center ul a {
           font-size: 18px;
           font-weight: 500;
           color: #fff;
           text-decoration: none;
       }

       .footer-center ul li {
           padding: 6px 0px;
       }

       .footer-right p {
           color: #fff;
           font-size: 15px;
           font-weight: 600;
           padding: 30px 0px;
       }
    </style>
</head>

<body id="page-top"  >
<div class="cartflows-container">

    <div data-elementor-type="post" data-elementor-id="84" class="elementor elementor-84" data-elementor-settings="[]">
        <div class="elementor-inner">
            <div class="elementor-section-wrap">
                <section class="elementor-element elementor-element-111f377 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="111f377" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;gradient&quot;,&quot;shape_divider_bottom&quot;:&quot;waves&quot;,&quot;shape_divider_bottom_negative&quot;:&quot;yes&quot;,&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
                    <h2 style="    position: absolute;
    top: 48px;
    font-size: 53px;
    left: 0;
    width: 100%;
    text-align: center;
    color: #fff;
    font-weight: bold;
    text-transform: uppercase;">Subscribe</h2>
                    <div class="elementor-background-overlay"></div>
                    <div class="elementor-shape elementor-shape-bottom" data-negative="true">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
                            <path class="elementor-shape-fill" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3
	c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3
	c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z" />
                        </svg>
                    </div>

                </section>


            </div>
        </div>
    </div>
</div>



<section >
    <div class="container">
        <form action="<?php echo e(route('/register-package')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="col-md-8 " style="margin: 0 auto;">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12 box_group">
                                <div class="card">
                                    <div class="card-body">
                                        <h3>Billing For Us</h3>
                                        <div class="row">
                                            <div class="col-md-6 col-sm-6">
                                                <div class="form-group ">
                                                    <label>Name</label>
                                                    <input placeholder="Enter name" name="name" type="text" class="form-control">
                                                    <span class="text-danger">
                                                        <?php if($errors->has('name')): ?> <?php echo e($errors->first('name')); ?> <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-6">
                                                <div class="form-group ">
                                                    <label>Email</label>
                                                    <input placeholder="Enter email" name="email" type="text" class="form-control">
                                                    <span class="text-danger">
                                                        <?php if($errors->has('email')): ?> <?php echo e($errors->first('email')); ?> <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-6">
                                                <div class="form-group ">
                                                    <label>Address</label>
                                                    <input placeholder="Enter Address" name="address" type="text" class="form-control">
                                                    <span class="text-danger">
                                                        <?php if($errors->has('address')): ?> <?php echo e($errors->first('address')); ?> <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-6">
                                                <div class="form-group ">
                                                    <label>Whatsapp no</label>
                                                    <input placeholder="Enter whatsapp no" name="whatsapp_no" type="text" class="form-control">
                                                    <span class="text-danger">
                                                        <?php if($errors->has('whatsapp_no')): ?> <?php echo e($errors->first('whatsapp_no')); ?> <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-6">
                                                <div class="form-group ">
                                                    <label>Password</label>
                                                    <input placeholder="Enter password" name="password" type="password" class="form-control">
                                                    <span class="text-danger">
                                                        <?php if($errors->has('password')): ?> <?php echo e($errors->first('password')); ?> <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 box_group">
                                <div class="card">
                                    <div class="card-body">
                                        <h3>Tiktok</h3>
                                        <div class="row">
                                            <div class="col-md-6 col-sm-6">
                                                <div class="form-group ">
                                                    <label>Tiktok username</label>
                                                    <input placeholder="Enter tiktok username" name="tiktok_username" type="text" class="form-control">
                                                    <span class="text-danger">
                                                        <?php if($errors->has('tiktok_username')): ?> <?php echo e($errors->first('tiktok_username')); ?> <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-6">
                                                <div class="form-group ">
                                                    <label>Tiktok password</label>
                                                    <input placeholder="tiktok password" name="tiktok_password" type="password" class="form-control">
                                                    <span class="text-danger">
                                                        <?php if($errors->has('tiktok_password')): ?> <?php echo e($errors->first('tiktok_password')); ?> <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-6">
                                                <div class="form-group ">
                                                    <label>Tiktok County</label>
                                                    <input placeholder="Enter tiktok county" name="tiktok_county" type="text" class="form-control">
                                                    <span class="text-danger">
                                                        <?php if($errors->has('tiktok_county')): ?> <?php echo e($errors->first('tiktok_county')); ?> <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-6">
                                                <div class="form-group ">
                                                    <label>Tiktok target interest</label>
                                                    <input placeholder="Enter tiktok target interest" name="tiktok_target_interest" type="text" class="form-control">
                                                    <span class="text-danger">
                                                        <?php if($errors->has('tiktok_target_interest')): ?> <?php echo e($errors->first('tiktok_target_interest')); ?> <?php endif; ?>
                                                    </span>

                                                </div>
                                            </div>
                                            <div class="col-md-6 col-sm-6">
                                                <div class="form-group ">
                                                    <label>Tiktok follower number</label>
                                                    <input placeholder="Enter tiktok follower number" name="tiktok_follower_no" type="text" class="form-control">
                                                    <span class="text-danger">
                                                        <?php if($errors->has('tiktok_follower_no')): ?> <?php echo e($errors->first('tiktok_follower_no')); ?> <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 box_group">
                                <div class="card">
                                    <div class="card-body">
                                        <h3>Your Order</h3>
                                        <table class="table table-bordered ">
                                            <tr class="">
                                                <th>Product</th>
                                                <th>Total</th>
                                            </tr>
                                            <tr class="">
                                                <th>Package </th>
                                                <th>£25.00 / 30 days + a free trial of 2 days</th>
                                            </tr>
                                            <tr class="">
                                                <th>Subtotal</th>
                                                <th>£25.00</th>
                                            </tr>
                                            <tr class="">
                                                <th>Total</th>
                                                <th>£25.00</th>
                                            </tr>
                                        </table>
                                        <div class="col-md-12">
                                            <label for="payment_method_ppec_paypal" class="paypal-area">
                                                <input checked type="radio" name="age" value="100">   PayPal <img src="https://www.paypalobjects.com/webstatic/en_US/i/buttons/pp-acceptance-small.png" alt="PayPal">	</label>
                                            <br><label for="payment_method_ppec_paypal" class="paypal-area">
                                                <input  type="radio" name="age" value="100">   BeGateway	</label>

                                        </div>
                                         <div class="col-md-12">
                                          <div class="button-area-sub">
                                              <div class="form-group">
                                                  <input type="submit" value="Subscribe" class="btn btn-success btn-block">
                                              </div>
                                              <a href="<?php echo e(route('/user-login')); ?>">If you already subscribe than click hear to login</a>

                                          </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <br>
            <br>
        </form>
    </div>
</section>
<section class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-4">
                <div class="footer-left">
                    <h3>ADDRESS</h3>
                    <p>Architectbot GmbH, Steuer ID 193189471</p>
                    <p>Radialnaya Str 11B/20a, 220070 Minsk, Belarus</p>
                </div>
            </div>
            <div class="col-md-4 col-sm-4">
                <div class="footer-center">
                    <ul>
                        <li><a href="https://tiktokfabrik.de/bepaid/"> Bepaid </a></li>
                        <li><a href="https://tiktokfabrik.de/terms-and-conditions/"> Terms And Conditions</a></li>
                        <li><a href=""> Certificate Of State Registration</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-4 col-sm-4">
                <div class="footer-right">
                   <p> © 2019 ARCHITECTBOT ALLE RECHTE VORBEHALTEN</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="vendor/chart.js/Chart.min.js"></script>

<!-- Page level custom scripts -->
<script src="js/demo/chart-area-demo.js"></script>
<script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>

<?php /**PATH /home/architec/laravel/resources/views/front-end/register-package/register-package.blade.php ENDPATH**/ ?>