<?php $__env->startSection('title'); ?>
    Manage User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    Manage User
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <section>
        <div class="row">
            <div class="col-md-12">
                <div class="card shadow">
                    <div class="card-body">
                        <table class="table table-bordered text-center">
                            <tr class="">
                                <th>User Name</th>
                                <th>User Email</th>
                                <th>User Status</th>
                                <th>details</th>
                            </tr>
                            <?php $__currentLoopData = $front_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $front_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($front_user->name); ?></td>
                                    <td><?php echo e($front_user->email); ?></td>
                                    <td><?php if($front_user->subscription_status == 1): ?>
                                            <span class="text-success">Active</span>
                                        <?php else: ?>
                                            <span class="text-danger">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><a href="<?php echo e(route('/view/user-profile',['id'=>$front_user->id])); ?>" class="btn btn-info btn-xs"><i class="fas fa-eye"></i></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back-end.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\paypal-project\resources\views/back-end/inactive/inactive-user.blade.php ENDPATH**/ ?>