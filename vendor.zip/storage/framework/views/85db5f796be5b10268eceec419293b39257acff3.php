
<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <section>
        <div class="row">
            <div class="col-md-12">
                <div class="card shadow">
                    <div class="card-body">
                       <div class="text-center text-success">
                           <h2 class="p-5">Welcome <?php echo e($front_user->name); ?></h2>
                       </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/architec/laravel/resources/views/front-end/dashboard/dashboard.blade.php ENDPATH**/ ?>