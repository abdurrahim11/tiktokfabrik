
<?php $__env->startSection('title'); ?>
    Subscription  status
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-title'); ?>
    Subscription  status
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <section>
        <div class="row">
            <div class="col-md-12">
                <div class="card shadow">
                    <div class="card-body">
                        <?php if($front_user->subscription_status == 1): ?>
                            <h3 class="text-black text-center">Your subscription status is <span class="text-success text-center">active </span></h3>
                           <div class="text-center mt-3">
                               <a href="<?php echo e(route('/cancel-sub',[
                               'id'  => $front_user->payer_id
                               ])); ?>" class="btn btn-danger">Cancel subscription</a>
                           </div>
                            <br>
                            <table class="table table-bordered ">
                                <tr class="">
                                    <th>Next billing date</th>
                                    <th><?php echo e($AgreementDetails->agreement_details->next_billing_date); ?></th>
                                </tr>

                                <tr class="">
                                    <th>Last payment date</th>
                                    <th><?php echo e($AgreementDetails->agreement_details->last_payment_date); ?></th>
                                </tr>
                            </table>
                        <?php else: ?>
                            <h3 class="text-black text-center">Your subscription status is <span class="text-danger text-center">inactive </span></h3>

                            <div class="text-center mt-3">
                                <a href="<?php echo e(route('/active-sub')); ?>" class="btn btn-success">Active subscription</a>
                            </div>

                            <br>
                            <table class="table table-bordered ">
                                <tr class="">
                                    <th>Next billing date</th>
                                    <th><?php echo e($AgreementDetails->agreement_details->next_billing_date); ?></th>
                                </tr>

                                <tr class="">
                                    <th>Last payment date</th>
                                    <th><?php echo e($AgreementDetails->agreement_details->last_payment_date); ?></th>
                                </tr>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/architec/laravel/resources/views/front-end/account-status/account-status.blade.php ENDPATH**/ ?>