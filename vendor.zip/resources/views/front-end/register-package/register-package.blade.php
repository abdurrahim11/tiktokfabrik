<!DOCTYPE html>
<html lang="en-US" class="no-js">

<!-- Mirrored from tiktokfabrik.de/checkout-woo/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 10 Nov 2019 20:05:57 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<!-- /Added by HTTrack -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <title>Subscribe</title>
    <link rel='stylesheet' id='qlwapp-css' href='{{asset('/')}}oldfile/wp-content/plugins/wp-whatsapp-chat/assets/css/qlwapp.min2827.css?ver=4.4.8' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-icons-css' href='{{asset('/')}}oldfile/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.minb2f9.css?ver=4.3.0' type='text/css' media='all' />
    <link rel='stylesheet' id='font-awesome-css' href='{{asset('/')}}oldfile/wp-content/plugins/elementor/assets/lib/font-awesome/css/font-awesome.min1849.css?ver=4.7.0' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-animations-css' href='{{asset('/')}}oldfile/wp-content/plugins/elementor/assets/lib/animations/animations.min737b.css?ver=2.5.15' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-frontend-css' href='{{asset('/')}}oldfile/wp-content/plugins/elementor/assets/css/frontend.min737b.css?ver=2.5.15' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-pro-css' href='{{asset('/')}}oldfile/wp-content/plugins/elementor-pro/assets/css/frontend.mined42.css?ver=2.5.8' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-global-css' href='{{asset('/')}}oldfile/wp-content/uploads/elementor/css/global42af.css?ver=1572446417' type='text/css' media='all' />
    <link rel='stylesheet' id='elementor-post-84-css' href='{{asset('/')}}oldfile/wp-content/uploads/elementor/css/post-84b453.css?ver=1572447251' type='text/css' media='all' />

    <!-- Custom fonts for this template-->
    <link href="{{asset('/')}}asset/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="{{asset('/')}}asset/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="{{asset('/')}}asset/css/style.css" rel="stylesheet">
    <style>

       label.paypal-area {
           margin: 0;
           font-size: 20px;
           font-weight: 800;
           padding: 3px 0px 15px 0px;
       }

       input.btn.btn-success.btn-block {
           background: #4167F9;
           margin: 0;
           padding: 13px 10px;
           font-size: 27px;
           font-weight: 600;
       }
       label {
           color: black;
           font-weight: 700;
       }
       section.footer {
           background: #022E47;
           padding: 50px 0px;
           text-align: center;
       }

       .footer-left {}

       .footer-left h3 {color: white;font-weight: 700;}

       .footer-left p {
           color: #ffff;
           font-size: 16px;
       }

       .footer-center ul {
           list-style: none;
       }

       .footer-center ul a {
           font-size: 18px;
           font-weight: 500;
           color: #fff;
           text-decoration: none;
       }

       .footer-center ul li {
           padding: 6px 0px;
       }

       .footer-right p {
           color: #fff;
           font-size: 15px;
           font-weight: 600;
           padding: 30px 0px;
       }
       hr.border-botton-top {
           border: none;
           background-image: linear-gradient( #4c60f582 , #4c60f50a);
           padding: 10px;
           position: relative;
       }

       hr.border-botton-top::before {
           content: "";
           position: absolute;
           top: 0;
           display: block;
           border-top: 5px solid #4c60f5;
           width: 100%;
           left: 0;
       }
       .your-order-reg  {
           background: #3e72f1;
           color: #fff;
           padding: 5px;
       }

       .your-order-reg h1 {
           background: #3e72f1;
           color: #fff;
           padding: 10px;
           font-size: 36px;
       }

       .plan-desti h2 {
           font-weight: 800;color: #656565;padding: 5px 0px;font-size: 27px;}

       .plan-desti p {
           margin-bottom: 0;
       }

       .plan-desti i {
           border: 2px solid #2c2c2c;
           font-size: 8px;
           padding: 4px;
           color: #fff;
           background: red;
           margin-right: 5px;
       }
       .your-order-reg h2 {
           font-size: 25px;
           font-weight: bold;
       }
       .plan-desti {margin-bottom: 15px;margin-top: 5px;}
    </style>
</head>

<body id="page-top"  >
<div class="cartflows-container">

    <div data-elementor-type="post" data-elementor-id="84" class="elementor elementor-84" data-elementor-settings="[]">
        <div class="elementor-inner">
            <div class="elementor-section-wrap">
                <section class="elementor-element elementor-element-111f377 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-id="111f377" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;gradient&quot;,&quot;shape_divider_bottom&quot;:&quot;waves&quot;,&quot;shape_divider_bottom_negative&quot;:&quot;yes&quot;,&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
                    <h2 style="    position: absolute;
    top: 48px;
    font-size: 53px;
    left: 0;
    width: 100%;
    text-align: center;
    color: #fff;
    font-weight: bold;
    text-transform: uppercase;">Subscribe</h2>
                    <div class="elementor-background-overlay"></div>
                    <div class="elementor-shape elementor-shape-bottom" data-negative="true">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
                            <path class="elementor-shape-fill" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3
	c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3
	c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z" />
                        </svg>
                    </div>

                </section>


            </div>
        </div>
    </div>
</div>



<section >
    <div class="container">
        <form action="{{route('/register-package')}}" method="POST">
            @csrf
            <div class="col-md-8 " style="margin: 0 auto;">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="card-body ">
                                <h3>Billing For Us</h3>
                                <hr class="border-botton-top">
                                <div class="row">
                                    <div class="col-md-6 col-sm-6">
                                        <div class="form-group ">
                                            <label>Name</label>
                                            <input placeholder="Enter name" name="name" type="text" class="form-control">
                                            <span class="text-danger">
                                                        @if($errors->has('name')) {{$errors->first('name')}} @endif
                                                    </span>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <div class="form-group ">
                                            <label>Email</label>
                                            <input placeholder="Enter email" name="email" type="text" class="form-control">
                                            <span class="text-danger">
                                                        @if($errors->has('email')) {{$errors->first('email')}} @endif
                                                    </span>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <div class="form-group ">
                                            <label>Address</label>
                                            <input placeholder="Enter Address" name="address" type="text" class="form-control">
                                            <span class="text-danger">
                                                        @if($errors->has('address')) {{$errors->first('address')}} @endif
                                                    </span>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <div class="form-group ">
                                            <label>Whatsapp no</label>
                                            <input placeholder="Enter whatsapp no" name="whatsapp_no" type="text" class="form-control">
                                            <span class="text-danger">
                                                        @if($errors->has('whatsapp_no')) {{$errors->first('whatsapp_no')}} @endif
                                                    </span>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-6">
                                        <div class="form-group ">
                                            <label>Password</label>
                                            <input placeholder="Enter password" name="password" type="password" class="form-control">
                                            <span class="text-danger">
                                                        @if($errors->has('password')) {{$errors->first('password')}} @endif
                                                    </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12 box_group">
                                <div class="card-body">
                                    <h3>Tiktok</h3>
                                    <hr class="border-botton-top">
                                    <div class="row">
                                        <div class="col-md-6 col-sm-6">
                                            <div class="form-group ">
                                                <label>Tiktok username</label>
                                                <input placeholder="Enter tiktok username" name="tiktok_username" type="text" class="form-control">
                                                <span class="text-danger">
                                                        @if($errors->has('tiktok_username')) {{$errors->first('tiktok_username')}} @endif
                                                    </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <div class="form-group ">
                                                <label>Tiktok password</label>
                                                <input placeholder="tiktok password" name="tiktok_password" type="password" class="form-control">
                                                <span class="text-danger">
                                                        @if($errors->has('tiktok_password')) {{$errors->first('tiktok_password')}} @endif
                                                    </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <div class="form-group ">
                                                <label>Tiktok County</label>
                                                <input placeholder="Enter tiktok county" name="tiktok_county" type="text" class="form-control">
                                                <span class="text-danger">
                                                        @if($errors->has('tiktok_county')) {{$errors->first('tiktok_county')}} @endif
                                                    </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <div class="form-group ">
                                                <label>Tiktok target interest</label>
                                                <input placeholder="Enter tiktok target interest" name="tiktok_target_interest" type="text" class="form-control">
                                                <span class="text-danger">
                                                        @if($errors->has('tiktok_target_interest')) {{$errors->first('tiktok_target_interest')}} @endif
                                                    </span>

                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-6">
                                            <div class="form-group ">
                                                <label>Tiktok follower number</label>
                                                <input placeholder="Enter tiktok follower number" name="tiktok_follower_no" type="text" class="form-control">
                                                <span class="text-danger">
                                                        @if($errors->has('tiktok_follower_no')) {{$errors->first('tiktok_follower_no')}} @endif
                                                    </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 box_group text-center">
                                <div class="card-body">
                                    <div class="your-order-reg">
                                        <h1>You order</h1>
                                    </div>
                                    <div class="plan-desti">
                                        <h2>BASIC</h2>
                                        <p><i class="fas fa-check"></i> <span>You are buying the "Growth at BASE speed" package</span></p>
                                        <p><i class="fas fa-check"></i> <span>Our team will work on your profile 4 hours a day for 30 days</span></p>
                                    </div>
                                    <div class="your-order-reg">
                                        <h2>Total</h2>
                                        <h2>99,00€</h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 text-center">
                                <label for="payment_method_ppec_paypal" class="paypal-area">
                                    <input checked type="radio" name="payment_method" value="PayPal">   PayPal <img src="https://www.paypalobjects.com/webstatic/en_US/i/buttons/pp-acceptance-small.png" alt="PayPal">	</label>
                                <label for="payment_method_ppec_paypal" class="paypal-area">
                                    <input  type="radio" name="payment_method" value="BeGateway">   BeGateway	</label>

                            </div>
                            <div class="col-md-12">
                                <div class="button-area-sub">
                                    <div class="form-group">
                                        <input type="submit" value="Subscribe" class="btn btn-success btn-block">
                                    </div>
                                    <a href="{{route('/user-login')}}">If you already subscribe than click hear to login</a>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <br>
        </form>
    </div>
</section>
<section class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-4">
                <div class="footer-left">
                    <h3>ADDRESS</h3>
                    <p>Architectbot GmbH, Steuer ID 193189471</p>
                    <p>Radialnaya Str 11B/20a, 220070 Minsk, Belarus</p>
                </div>
            </div>
            <div class="col-md-4 col-sm-4">
                <div class="footer-center">
                    <ul>
                        <li><a href="https://tiktokfabrik.de/bepaid/"> Bepaid </a></li>
                        <li><a href="https://tiktokfabrik.de/terms-and-conditions/"> Terms And Conditions</a></li>
                        <li><a href=""> Certificate Of State Registration</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-4 col-sm-4">
                <div class="footer-right">
                   <p> © 2019 ARCHITECTBOT ALLE RECHTE VORBEHALTEN</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="vendor/chart.js/Chart.min.js"></script>

<!-- Page level custom scripts -->
<script src="js/demo/chart-area-demo.js"></script>
<script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>

