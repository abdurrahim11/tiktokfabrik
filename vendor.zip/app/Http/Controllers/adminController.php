<?php

namespace App\Http\Controllers;

use App\front_user;
use Illuminate\Http\Request;

class adminController extends Controller
{

}
