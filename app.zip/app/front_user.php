<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class front_user extends Model
{
    //
}
